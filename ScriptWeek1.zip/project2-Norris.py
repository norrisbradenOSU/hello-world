Python 3.10.4 (v3.10.4:9d38120e33, Mar 23 2022, 17:29:05) [Clang 13.0.0 (clang-1300.0.29.30)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
name = "Braden Norris"
address = "123 Abc St"
number = "9181234567"
print("My name is ", name + ", my address is ", address + ", and my number is ", number)
My name is  Braden Norris, my address is  123 Abc St, and my number is  9181234567
