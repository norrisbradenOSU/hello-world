Python 3.10.4 (v3.10.4:9d38120e33, Mar 23 2022, 17:29:05) [Clang 13.0.0 (clang-1300.0.29.30)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
base = 5
height = 7
triangleArea = .5 * base * height
print(triangleArea)
17.5


base = 6
height = 5
triangleArea = .5 * base * height
print(triangleArea)
15.0


base = 10
height = 10
triangleArea = .5 * base * height
print(triangleArea)
50.0
