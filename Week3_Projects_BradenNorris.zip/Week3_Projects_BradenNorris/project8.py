seconds = 365*24*60*60
lightSpeed = (3 * pow(10,8))
lightYear = lightSpeed * seconds

print(lightYear)

