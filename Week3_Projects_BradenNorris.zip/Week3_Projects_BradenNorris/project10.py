hourlyWage = int(input("What is your hourly wage?: "))
hours = int(input("How many hours did you work?: "))
overtime = int(input("How many hours of overtime did you work?: "))
overtimeWage = overtime * (hourlyWage * 1.5)
weeklyPay = hourlyWage * hours + overtimeWage
print("Your weekly pay is  " + str(weeklyPay))