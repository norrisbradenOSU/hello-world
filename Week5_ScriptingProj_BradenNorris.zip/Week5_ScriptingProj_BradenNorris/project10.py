purchasePrice = float(input("Enter the purchase price: "))

#Initialize annual interest, and monthly rate
ANNUAL_INTEREST = 0.12
MONTHLY_RATE = 0.12/12

#Initialize the down payment, original balance, and payment
downPayment = purchasePrice * .1
origBalance = purchasePrice - downPayment
payment = origBalance * 0.05

#Print the title header
print("Month", "    Orig. Bal.", "      Monthly Interest", "Principal", "       Payment", "      New Bal.")

# Set month equal to one
month = 0
while origBalance > payment:

    month += 1
    interest = origBalance * MONTHLY_RATE
    principal = payment - interest
    newBalance = origBalance - principal
    print("%2d%16.2f%16.2f%18.2f%18.2f%15.2f" % (month, origBalance, interest, principal, payment, newBalance))
    origBalance = newBalance#Set value of the original balance equal to the old balance


#Calculate last month
payment=origBalance
interest=0
principal=payment
month = month+1
newBalance=0
print("%2d%16.2f%16.2f%18.2f%18.2f%15.2f" % (month, origBalance, interest, principal, payment, newBalance))