side1 = input("Enter the length of the first side: ")
side2 = input("Enter the length of the second side: ")
side3 = input("Enter the length of the third side: ")

if side1 == side2 == side3:
    print("The triangle is equilateral")
else:
    print("Not an equilateral triangle.")