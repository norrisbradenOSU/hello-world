side1 = int(input("Enter the length of the first side: "))
side2 = int(input("Enter the length of the second side: "))
side3 = int(input("Enter the length of the third side: "))

x = [side1, side2, side3]
sorted_x = sorted(x)
min_side = sorted_x[0]
second_side = sorted_x[1]
max_side = sorted_x[2]

if (min_side * min_side) + (second_side * second_side) == max_side * max_side:
    print("It is a right triangle")
else:
    print("Not a right triangle")


