''' This takes the radius of a sphere and then
calculates the diamter, circumference, surface area
and volume'''

import math


radius = float(input("What is the radius?: "))

diameter = radius * 2

circumference = (radius * 2) * math.pi

surfaceArea = 4 * math.pi * (radius * radius)

volume = (4/3 * math.pi * radius**3)

print("The diameter is " + str(diameter) + ". The circumference is " + str(circumference) + ". The surface area is " + str(surfaceArea) + ". The volume is " + str(volume))