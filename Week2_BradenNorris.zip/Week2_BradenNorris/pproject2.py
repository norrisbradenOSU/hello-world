length = float(input("What is the length of the edge?: "))

area = ((length * length) * 6)

print(area)