''' This program determines whether a movie is new or old then calculates how many nights it was rented and creates a total cost'''

movieType = input("New or old video?: ")
length = int(input("How many nights?: "))
movieType = movieType.lower()
x = 0

if movieType == "new":
    x = 3
elif movieType == "old":
    x = 2
else:
    print("Invalid answer, use new or old")

cost = x * length

print("The total cost is " + str(cost))